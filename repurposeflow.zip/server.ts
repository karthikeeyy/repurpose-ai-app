import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '50mb' }));

// Lazy creator for GoogleGenAI to handle missing keys gracefully
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Simulated data fallback if API Key is not set or fail-safes are needed
function generateLocalMockInsights(sourceText: string) {
  const cleanText = sourceText.slice(0, 300);
  return {
    title: `Repurposed Project: ${cleanText.split('\n')[0] || 'Social Engine Input'}`,
    summary: "This is a simulated fallback summary. To enable fully powered AI extraction, please configure your GEMINI_API_KEY inside the Settings > Secrets panel of your Google AI Studio workspace.",
    insights: [
      "AI Hook Mastery: The first 3 seconds determine 80% of click-through performance on vertical feeds.",
      "Omni-channel Formatting: Re-structure insights into 3 modular sections (hooks, text threads, image prompts) for efficiency.",
      "Audience Retention: End video scripts with direct loops or open loops instead of passive calls to action."
    ],
    hooks: [
      "I tested 42 content repurposing frameworks, and this single formula wins every time. (Thread 🧵👇)",
      "If you're still writing social posts manually in 2026, you are wasting 10+ hours a week.",
      "The exact blueprint used to turn a single 10-minute video into 15 high-performing posts."
    ],
    linkedinPost: "🚀 STOP wasting hours trying to adapt your long-form video content manually.\n\nThe future belongs to modular content engines. In our latest study, we analyzed 10,000+ social media campaigns to find what actually drives omni-channel engagement:\n\n1. High-tension hooks (first 3 seconds are make-or-break)\n2. Interactive formatting (threads over monolithic walls of text)\n3. Clear, immediate open-loops.\n\nHere is how we turn 1 video into a complete content engine. Read the full insights in our dashboard.\n\n#ContentStrategy #Marketing #GrowthHacking #AI",
    twitterThread: [
      "1/ Content repurposing is broken. Most creators just paste raw transcripts or write boring summaries. Here is the exact modular formula to build an omni-channel machine: 🧵",
      "2/ First, the Hook. Your hook shouldn't describe the topic; it should challenge a standard assumption. E.g., 'If you're still writing manually, you are wasting 10 hours.'",
      "3/ Second, modular distribution. Turn 1 concept into a X thread, a visual bento grid summary, and a text-based story. Start automated distribution today!"
    ]
  };
}

// API endpoint to extract insights
app.post('/api/extract', async (req, res) => {
  try {
    const { transcript, url, documentName } = req.body;
    
    let sourceContent = '';
    let sourceLabel = '';
    
    if (transcript && transcript.trim()) {
      sourceContent = transcript;
      sourceLabel = 'Text Transcript';
    } else if (url && url.trim()) {
      sourceContent = `URL to process: ${url}`;
      sourceLabel = `URL Ingestion (${url})`;
    } else if (documentName) {
      sourceContent = `Document: ${documentName}`;
      sourceLabel = `Document (${documentName})`;
    } else {
      return res.status(400).json({ error: 'Please provide a transcript, URL, or document.' });
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Return beautiful mock data with a warning
      const fallback = generateLocalMockInsights(sourceContent);
      return res.json({
        ...fallback,
        warning: 'Using high-fidelity fallback data. Configure your GEMINI_API_KEY in Secrets for real AI power.'
      });
    }

    const prompt = `
      You are an expert content strategist and repurposing machine.
      Analyze the following source material and extract high-value insights, catchy hooks, and formatted posts.
      
      Source Material:
      "${sourceContent}"
      
      Extract and structure the following fields:
      - title: A short, punchy, high-impact title for this repurposing project (max 6 words).
      - summary: A clear 2-sentence executive summary of the core message or thesis.
      - insights: Exactly 3 high-value bulleted insights, key takeaways, or metrics.
      - hooks: Exactly 3 highly viral, scroll-stopping hooks tailored to social feeds.
      - linkedinPost: A professional, beautifully formatted LinkedIn post with line breaks and hashtags.
      - twitterThread: Exactly a 3-part educational Twitter/X thread.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: 'OBJECT',
          properties: {
            title: { type: 'STRING' },
            summary: { type: 'STRING' },
            insights: {
              type: 'ARRAY',
              items: { type: 'STRING' },
              description: 'Exactly 3 core insights or takeaways'
            },
            hooks: {
              type: 'ARRAY',
              items: { type: 'STRING' },
              description: 'Exactly 3 scroll-stopping hooks'
            },
            linkedinPost: { type: 'STRING', description: 'A polished, spaced-out LinkedIn post with hashtags' },
            twitterThread: {
              type: 'ARRAY',
              items: { type: 'STRING' },
              description: 'Exactly a 3-part thread'
            }
          },
          required: ['title', 'summary', 'insights', 'hooks', 'linkedinPost', 'twitterThread']
        }
      }
    });

    if (response.text) {
      const parsed = JSON.parse(response.text);
      return res.json(parsed);
    } else {
      throw new Error('Empty response from Gemini API');
    }

  } catch (error: any) {
    console.error('Error in /api/extract:', error);
    res.status(500).json({
      error: error.message || 'Internal server error processing insights.',
      fallback: generateLocalMockInsights(req.body.transcript || req.body.url || '')
    });
  }
});

// API endpoint for editor assistant (refining selected pieces)
app.post('/api/editor/assist', async (req, res) => {
  try {
    const { text, instruction } = req.body;
    if (!text || !instruction) {
      return res.status(400).json({ error: 'Text and instruction are required.' });
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Beautiful mock refinement
      return res.json({
        revisedText: `✨ [Mock AI Refinement] ✨\nOriginal: "${text}"\n\nRevised based on: "${instruction}":\n\n📢 Here is the polished result! We've made it punchier, aligned the rhythm, and optimized it for ultimate social distribution. Give it a spin!`,
        warning: 'Configure your GEMINI_API_KEY in Secrets for real AI power.'
      });
    }

    const prompt = `
      You are an elite copywriter. Revise the following text according to the exact instruction.
      Keep the formatting clean and maintain the general topic. Return ONLY the final revised text. No introductions, no comments.
      
      Original Text:
      "${text}"
      
      Instruction:
      "${instruction}"
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
    });

    if (response.text) {
      return res.json({ revisedText: response.text.trim() });
    } else {
      throw new Error('Empty response from Gemini API');
    }

  } catch (error: any) {
    console.error('Error in /api/editor/assist:', error);
    res.status(500).json({ error: error.message || 'Failed to polish content.' });
  }
});

// Serve frontend assets
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
} else {
  // Vite Dev Server middleware mode
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
}

const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`[RepurposeFlow] Server running on http://0.0.0.0:${PORT}`);
});
