import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Cpu, 
  Globe, 
  Activity, 
  HardDrive, 
  Zap, 
  Check, 
  Copy, 
  FileText, 
  Link2, 
  UploadCloud, 
  CheckCircle2, 
  ArrowRight, 
  Edit3, 
  Trash2, 
  Save, 
  BookOpen, 
  PlusCircle, 
  LayoutGrid, 
  Settings, 
  RefreshCw, 
  Twitter, 
  Linkedin, 
  History, 
  Sliders, 
  Info,
  ExternalLink,
  Flame,
  Volume2,
  Lock,
  ChevronRight
} from 'lucide-react';

// Pre-seeded high-fidelity projects
interface Project {
  id: string;
  title: string;
  sourceType: 'transcript' | 'url' | 'document';
  sourceLabel: string;
  timestamp: string;
  summary: string;
  insights: string[];
  hooks: string[];
  linkedinPost: string;
  twitterThread: string[];
}

const PRE_SEEDED_PROJECTS: Project[] = [
  {
    id: 'proj-1',
    title: 'GaryVee Creator Secrets',
    sourceType: 'transcript',
    sourceLabel: 'Text Transcript (GaryVee Keynote)',
    timestamp: '2026-07-07 07:01',
    summary: 'Personal branding is no longer optional; it is a critical leverage framework. Re-investing short-form attention into premium, owned community assets is the only path to infinite customer lifetime value.',
    insights: [
      'The 1-to-20 Rule: Distribute 1 core long-form piece of content into 20 micro-hooks across 5 core platforms to scale voice.',
      'Community Leverage: Systematically move platform-owned transactional traffic into robust, owned email or SMS networks.',
      'Organic Multiplier: Consistent daily native uploads outperform paid advertising by 340% over an 18-month strategy.'
    ],
    hooks: [
      'If you\'re building a business but neglecting your personal brand, you are leaving 90% of your profit on the table. (Thread 🧵👇)',
      'The absolute biggest mistake I see 99% of creators make when starting on short-form video in 2026.',
      'How to turn a single 15-minute podcast episode into 30 high-performing pieces of social content without hiring a huge team.'
    ],
    linkedinPost: "🚀 STOP treating social media like a megaphone. It is a telephone.\n\nThe real leverage of modern marketing isn't broad reach—it is conversational connection.\n\nEvery single piece of content you produce is a seed. If you do not water it by actively engaging in the comments, replying to DMs, and moving attention to owned lists, those seeds will dry up.\n\nHere is my 3-step formula to scale your brand organically:\n\n1. Post with value first (Zero sales pitch)\n2. Comment on 20 industry leaders' pages daily\n3. Shift high-intent readers to your newsletter\n\nScale the unscalable to build something permanent.\n\n#PersonalBranding #Entrepreneurship #GaryVee #SocialMediaStrategy",
    twitterThread: [
      "1/ Personal branding is no longer optional. It is the ultimate insurance policy for your career and business. Here is the exact blueprint to build yours in under 4 hours a week: 🧵",
      "2/ Document, don't create. Stop trying to look perfect or sound like an academic. Show the behind-the-scenes struggles, real metrics, and daily decisions. Authenticity is the ultimate differentiator.",
      "3/ The 1-to-20 engine: Take 1 long-form video, transcribe it, extract 3 core insights, and turn them into 5 platform-specific posts. Scale your voice without burning out."
    ]
  },
  {
    id: 'proj-2',
    title: 'MrBeast Thumbnail Secrets',
    sourceType: 'document',
    sourceLabel: 'Document (MrBeast_Deck.pdf)',
    timestamp: '2026-07-06 14:32',
    summary: 'Click-through rate (CTR) is the single most dominant factor in social algorithms. Visual tension, immediate high-contrast focal points, and narrative consistency are required to achieve sub-second clicks.',
    insights: [
      'The 1000ms Rule: A user must fully comprehend the core emotional stakes of your asset within 1 second of visual scanning.',
      'Gaze Direction: Ensure faces look directly at the viewer or the primary action to establish a deep biological connection.',
      'Color Contrast: Leverage opposite color pairs (e.g. Orange & Teal) to disrupt flat platform backgrounds.'
    ],
    hooks: [
      'The psychological trick MrBeast uses in his thumbnails that forces your brain to click. (Revealed 🧵)',
      'We spent 100+ hours analyzing the top 1,000 YouTube thumbnails. Here are the 3 design patterns that actually drive CTR.',
      'Your video edits don\'t matter if your thumbnail fails. Here is the checklist to instantly double your view counts.'
    ],
    linkedinPost: "🧠 Thumbnail design is not art—it is cognitive neuroscience.\n\nWe analyzed 1,000 top-performing digital assets to map user scanning patterns. The results are clear: the human brain prioritizes emotional clarity over high production value.\n\nHere are the 3 visual pillars of scroll-stopping click-through rates:\n\n1. Biological focal points (clear facial expressions displaying high-intensity surprise or tension)\n2. High-contrast opposite colors to segment foreground and background\n3. Rule of Thirds alignment with zero text overlapping critical faces\n\nMaximize your CTR to unlock YouTube's recommendation engine.\n\n#YouTubeMarketing #CreativeDesign #CTR #MrBeastSecrets #VisualStrategy",
    twitterThread: [
      "1/ Most YouTube creators spend 40 hours editing and 40 seconds designing their thumbnails. This is a recipe for zero views. Here is the complete design checklist used by top 1% channels: 🧵",
      "2/ Rule 1: High Emotional Density. The faces in your thumbnail should display extreme emotions (terror, ecstasy, curiosity). Neutral faces get scrolled past immediately.",
      "3/ Rule 2: Simplify the elements. Limit your thumbnail to exactly 3 core elements: 1 subject face, 1 action object, and 1 high-contrast background. Less is infinitely more."
    ]
  },
  {
    id: 'proj-3',
    title: 'SpaceX First Principles',
    sourceType: 'url',
    sourceLabel: 'URL (https://youtube.com/watch?v=ElonMusk)',
    timestamp: '2026-07-05 18:22',
    summary: 'Breakthrough innovation requires breaking concepts down to their fundamental physical truths rather than reasoning by analogy. This framework minimizes capital expenditure while maximizing iteration velocity.',
    insights: [
      'Analogical Traps: Reasoning by analogy leads to incremental improvements; First Principles leads to exponential innovation.',
      'Cost-Basis Reduction: Analyze raw material costs (e.g. aerospace aluminum) rather than third-party market markups.',
      'Velocity Over Perfection: Establish tight feedback loops to fail fast, gather telemetry, and iterate the design.'
    ],
    hooks: [
      'Elon Musk\'s First Principles thinking explained in 3 simple steps. (How to solve any impossible problem 🧵)',
      'Why reasoning by analogy is keeping your business stuck, and how to think like a rocket scientist.',
      'The engineering framework SpaceX used to reduce rocket manufacturing costs by 90%.'
    ],
    linkedinPost: "💡 'I think it's important to reason from first principles rather than by analogy.' — Elon Musk\n\nMost organizations are trapped in historical analogies: 'We do it this way because that's how it has always been done.' This is how legacy industries become vulnerable to disruption.\n\nFirst principles thinking forces you to:\n\n1. Identify your core assumptions ('Space flight is too expensive')\n2. Break the problem down to its absolute fundamental truths (What are the raw material costs of a rocket?)\n3. Rebuild the solution from scratch (Build the rocket in-house using basic aerospace metals)\n\nInnovate at the level of physical laws, not corporate trends.\n\n#FirstPrinciples #Innovation #Engineering #ProductDesign #SpaceX",
    twitterThread: [
      "1/ How did SpaceX reduce the cost of space flight by 90%? It wasn't through better negotiations. It was through a mental model called First Principles thinking. Here is how you can use it: 🧵",
      "2/ Identify your foundational assumptions. If you're building a SaaS, don't ask 'What are our competitors charging?' Ask 'What does it physically cost to run 1 server instance and store 1 gigabyte of data?'",
      "3/ Rebuild the solution from the ground up. By focusing strictly on physical raw costs rather than industry markup, you can identify hidden margins and create true market-disrupting value."
    ]
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'source' | 'projects' | 'editor' | 'library'>('source');
  
  // Ingest Form States
  const [transcript, setTranscript] = useState<string>('');
  const [url, setUrl] = useState<string>('');
  const [documentName, setDocumentName] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isToastVisible, setIsToastVisible] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'warning' }>({ text: '', type: 'success' });

  // Projects State
  const [projects, setProjects] = useState<Project[]>(PRE_SEEDED_PROJECTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('proj-1');
  const selectedProject = projects.find(p => p.id === selectedProjectId) || projects[0];

  // Editor State
  const [editorTitle, setEditorTitle] = useState<string>('GaryVee Hooks Content');
  const [editorContent, setEditorContent] = useState<string>('');
  const [aiInstruction, setAiInstruction] = useState<string>('');
  const [isEditorLoading, setIsEditorLoading] = useState<boolean>(false);

  // File Upload Reference
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Live System logs
  const [logs, setLogs] = useState<Array<{ time: string; msg: string; type: 'success' | 'info' | 'warn' | 'live' }>>([
    { time: '07:06:08', msg: 'AUTH_SUCCESS • Session initialized for karthikbineesh335@gmail.com', type: 'success' },
    { time: '07:06:12', msg: 'DB_HEALTH • Firebase and local cache synched cleanly', type: 'info' },
    { time: '07:06:15', msg: 'METADATA_LOAD • Active capabilities loaded: SERVER_SIDE_GEMINI_API', type: 'live' },
    { time: '07:06:44', msg: 'CACHE_PURGE • Regional-US-East clusters optimized', type: 'info' },
  ]);

  // Handle Toast Notifications
  const showToast = (text: string, type: 'success' | 'error' | 'warning') => {
    setToastMessage({ text, type });
    setIsToastVisible(true);
    setTimeout(() => {
      setIsToastVisible(false);
    }, 4500);
  };

  // Pre-fill transcript using preset strategies (convenient for users to test without typing)
  const loadPresetTranscript = (presetName: string) => {
    if (presetName === 'mrbeast') {
      setTranscript(`We tested 1,000 top YouTube thumbnails to find what actually makes viewers click. The algorithm rewards emotional intensity, absolute visual simplification, and high color-contrast ratio. A classic error is overlaying text on top of human faces, which confuses the viewer's gaze sequence. Focus instead on opposite color pairs like purple/teal and ensure the gaze vector looks straight at the viewer.`);
      setDocumentName('MrBeast_Deck.txt');
      setUrl('');
      showToast('Pre-loaded MrBeast Masterclass transcript', 'success');
    } else if (presetName === 'marketing') {
      setTranscript(`Social media is moving towards owned distribution models. Building community channels inside private spaces or using high-conversion email triggers outperforms simple raw platform feeds. We recommend structuring every 10-minute content piece into 20 micro-assets across 5 channels to double distribution leverage.`);
      setDocumentName('Creator_Leverage_Doc.txt');
      setUrl('');
      showToast('Pre-loaded Marketing distribution preset', 'success');
    }
  };

  // Ingestion: Extract Insights using API
  const handleExtractInsights = async () => {
    if (!transcript.trim() && !url.trim() && !documentName) {
      showToast('Please provide a transcript, paste a URL, or load a document preset first.', 'warning');
      return;
    }

    setIsLoading(true);
    // Add real-time pending log
    const timestamp = new Date().toTimeString().split(' ')[0];
    setLogs(prev => [
      { time: timestamp, msg: 'API_REQUEST • Dispatching extraction job to Gemini API...', type: 'info' },
      ...prev
    ]);

    try {
      const response = await fetch('/api/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript: transcript,
          url: url,
          documentName: documentName || 'Raw Text Feed'
        })
      });

      const data = await response.json();
      
      if (response.ok) {
        const newProject: Project = {
          id: `proj-${Date.now()}`,
          title: data.title || 'New Extracted Project',
          sourceType: url ? 'url' : (documentName ? 'document' : 'transcript'),
          sourceLabel: url ? `URL Ingestion (${url})` : (documentName || 'Text Transcript Input'),
          timestamp: new Date().toISOString().slice(0, 16).replace('T', ' '),
          summary: data.summary,
          insights: data.insights,
          hooks: data.hooks,
          linkedinPost: data.linkedinPost,
          twitterThread: data.twitterThread
        };

        setProjects(prev => [newProject, ...prev]);
        setSelectedProjectId(newProject.id);
        
        // Push successful log
        const finTimestamp = new Date().toTimeString().split(' ')[0];
        setLogs(prev => [
          { time: finTimestamp, msg: `INSIGHTS_SUCCESS • Processed "${newProject.title}" with 3.5-flash`, type: 'success' },
          ...prev
        ]);

        if (data.warning) {
          showToast(`Extracted successfully! (Note: ${data.warning})`, 'warning');
        } else {
          showToast(`Successfully extracted insights from "${newProject.title}"!`, 'success');
        }
        
        // Transition to Projects Tab to see results instantly
        setActiveTab('projects');
      } else {
        throw new Error(data.error || 'Server returned an error');
      }

    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to communicate with the Gemini extraction engine.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // Assist: Polish Text in Editor using API
  const handleAIAssist = async (presetInstruction?: string) => {
    const instruction = presetInstruction || aiInstruction;
    if (!editorContent.trim()) {
      showToast('The editor is currently empty. Please select content to edit first.', 'warning');
      return;
    }
    if (!instruction.trim()) {
      showToast('Please type a custom instruction or select an AI preset.', 'warning');
      return;
    }

    setIsEditorLoading(true);
    const timestamp = new Date().toTimeString().split(' ')[0];
    setLogs(prev => [
      { time: timestamp, msg: `EDITOR_AI • Refining content with Gemini...`, type: 'info' },
      ...prev
    ]);

    try {
      const response = await fetch('/api/editor/assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: editorContent,
          instruction: instruction
        })
      });

      const data = await response.json();

      if (response.ok) {
        setEditorContent(data.revisedText);
        setAiInstruction('');
        const finTimestamp = new Date().toTimeString().split(' ')[0];
        setLogs(prev => [
          { time: finTimestamp, msg: 'EDITOR_SUCCESS • Polish applied successfully', type: 'success' },
          ...prev
        ]);
        
        if (data.warning) {
          showToast(`Content refined! (Note: ${data.warning})`, 'warning');
        } else {
          showToast('Content successfully optimized by Gemini!', 'success');
        }
      } else {
        throw new Error(data.error || 'Failed to refine text');
      }
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'AI refinement failed.', 'error');
    } finally {
      setIsEditorLoading(false);
    }
  };

  // Helper to load content to Editor
  const openInEditor = (title: string, text: string) => {
    setEditorTitle(title);
    setEditorContent(text);
    setActiveTab('editor');
    showToast(`Loaded "${title}" into Content Laboratory`, 'success');
  };

  // Copy to Clipboard Utility
  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`Copied ${label} to clipboard!`, 'success');
  };

  // File input drag/drop or select
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDocumentName(file.name);
      setUrl('');
      const reader = new FileReader();
      reader.onload = (event) => {
        if (typeof event.target?.result === 'string') {
          setTranscript(event.target.result);
          showToast(`Loaded ${file.name} text successfully! Ready to extract.`, 'success');
        }
      };
      reader.readAsText(file);
    }
  };

  // Trigger file selection
  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-white flex flex-col relative overflow-x-hidden select-none pb-24 md:pb-8">
      {/* Background Atmosphere Globs */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full pointer-events-none z-0"></div>
      <div className="absolute top-[40%] -left-24 w-96 h-96 bg-purple-500/5 blur-[120px] rounded-full pointer-events-none z-0"></div>

      {/* Floating Toast Notification */}
      {isToastVisible && (
        <div className="fixed top-6 right-6 z-50 animate-bounce duration-500 flex items-center gap-3 bg-zinc-900 border border-zinc-800 p-4 rounded-xl shadow-2xl max-w-md">
          {toastMessage.type === 'success' && (
            <div className="w-6 h-6 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center font-bold">
              <Check className="w-4 h-4" />
            </div>
          )}
          {toastMessage.type === 'warning' && (
            <div className="w-6 h-6 bg-amber-500/20 text-amber-400 rounded-full flex items-center justify-center font-bold">
              <Info className="w-4 h-4" />
            </div>
          )}
          {toastMessage.type === 'error' && (
            <div className="w-6 h-6 bg-rose-500/20 text-rose-400 rounded-full flex items-center justify-center font-bold">
              <Zap className="w-4 h-4" />
            </div>
          )}
          <p className="text-sm font-medium text-zinc-300">{toastMessage.text}</p>
        </div>
      )}

      {/* Navigation Header */}
      <header className="w-full sticky top-0 z-40 bg-[#09090b]/80 backdrop-blur-md border-b border-zinc-900 px-6 py-4 max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-600/30">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-xl font-bold font-['Montserrat'] tracking-tight">RepurposeFlow</span>
            <span className="text-[10px] block text-indigo-400 font-mono tracking-widest uppercase">BENTO CONTENT ENGINE</span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex gap-6 text-sm font-semibold text-zinc-400">
          <button 
            id="nav-source-desktop"
            onClick={() => setActiveTab('source')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 ${activeTab === 'source' ? 'text-white bg-zinc-900 border border-zinc-800' : 'hover:text-zinc-200'}`}
          >
            Source Input
          </button>
          <button 
            id="nav-projects-desktop"
            onClick={() => setActiveTab('projects')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 ${activeTab === 'projects' ? 'text-white bg-zinc-900 border border-zinc-800' : 'hover:text-zinc-200'}`}
          >
            Projects
          </button>
          <button 
            id="nav-editor-desktop"
            onClick={() => setActiveTab('editor')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 ${activeTab === 'editor' ? 'text-white bg-zinc-900 border border-zinc-800' : 'hover:text-zinc-200'}`}
          >
            Editor Lab
          </button>
          <button 
            id="nav-library-desktop"
            onClick={() => setActiveTab('library')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 ${activeTab === 'library' ? 'text-white bg-zinc-900 border border-zinc-800' : 'hover:text-zinc-200'}`}
          >
            Stats & Formulas
          </button>
        </nav>

        {/* Profile & Settings Trigger */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-zinc-900/60 px-3 py-1.5 rounded-full border border-zinc-800">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-xs text-zinc-400 font-mono">3.5-Flash Live</span>
          </div>
          <div className="w-8 h-8 rounded-full border border-zinc-800 bg-zinc-800 overflow-hidden flex items-center justify-center">
            <img 
              className="w-full h-full object-cover" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuC8hsZ6Ddfjk83yQ-bYyqIiMZejnpM-t5JZoSU4tdhzM54IwuKGIaBc0L3Mp3USNTvxyMgDlQEp8F9mA2MFtRmJrcvg-0NRE24oX7FaR4ejQDZHt86o3ku3NxVckOORBq4hmAfSq-LDdj6eNUhq1z94ZLxsTiqZkz2i6BDW-pzBbY2lZeoF0xh0TkR67ZHs9yctJ1fDJLqS5-n6bRqGgUPvLVJQwUq0WhcDUazY-qMCQfTM3q25nEWZop_h7chWXpmst7NOeelciJP-" 
              alt="User profile" 
            />
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-6 z-10 relative">
        
        {/* TAB 1: SOURCE INPUT */}
        {activeTab === 'source' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in duration-300">
            
            {/* Left intro section */}
            <div className="lg:col-span-4 flex flex-col justify-between py-2">
              <div>
                <span className="px-3 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-[10px] font-bold tracking-widest uppercase mb-4 inline-block">
                  Knowledge Ingestion
                </span>
                <h1 className="text-4xl lg:text-5xl font-extrabold font-['Montserrat'] tracking-tighter text-white leading-none mt-2">
                  Feed the <br />Machine.
                </h1>
                <p className="mt-4 text-zinc-400 text-base leading-relaxed font-['Inter'] max-w-md">
                  Paste raw transcripts, supply content URLs, or drop key documents. Our AI systematically extracts viral insights and structures ready-to-post material to fuel your multi-channel engine.
                </p>

                {/* Instant Presets for easy testing */}
                <div className="mt-6">
                  <span className="text-xs text-zinc-500 uppercase tracking-widest font-bold block mb-3">Quick Presets (Test Instant-Click)</span>
                  <div className="flex flex-wrap gap-2">
                    <button 
                      onClick={() => loadPresetTranscript('mrbeast')}
                      className="px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs font-semibold text-zinc-300 hover:border-indigo-500 hover:text-white transition-all flex items-center gap-1.5"
                    >
                      <Flame className="w-3.5 h-3.5 text-amber-500" /> MrBeast CTR Lesson
                    </button>
                    <button 
                      onClick={() => loadPresetTranscript('marketing')}
                      className="px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs font-semibold text-zinc-300 hover:border-indigo-500 hover:text-white transition-all flex items-center gap-1.5"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-indigo-400" /> Owned Audiences
                    </button>
                  </div>
                </div>
              </div>

              {/* Pro Tip Card */}
              <div className="mt-8 p-5 rounded-2xl bg-zinc-900/50 border border-zinc-800 flex gap-4 items-start">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Strategic Recommendation</h4>
                  <p className="text-xs text-zinc-400 mt-1 font-['Inter']">
                    Clean, high-fidelity verbatim video transcripts result in 40% higher accuracy for hooks and target platform adaptations.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Bento Grid Form */}
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Main Transcript Textarea */}
              <div className="md:col-span-2 glass-card rounded-[2rem] p-6 shadow-xl relative overflow-hidden group">
                <div className="absolute -top-12 -right-12 w-48 h-48 bg-indigo-500/5 blur-3xl rounded-full"></div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold tracking-widest text-zinc-400 uppercase">1. Paste Raw Transcript</span>
                    {documentName && (
                      <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full text-[10px] font-mono">
                        {documentName}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-zinc-500 font-mono italic">Up to 50k characters</span>
                </div>
                <textarea 
                  value={transcript}
                  onChange={(e) => {
                    setTranscript(e.target.value);
                    if (documentName) setDocumentName('');
                  }}
                  className="w-full h-56 bg-zinc-950/40 border border-zinc-900 rounded-2xl p-4 text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-indigo-500 transition-colors resize-none font-sans"
                  placeholder="Paste your video text, podcast transcript, or core strategy documentation here..."
                />
              </div>

              {/* Paste URL Bento Card */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Link2 className="w-4 h-4 text-indigo-400" />
                    <span className="text-xs font-bold tracking-widest text-zinc-400 uppercase">2. Supply Content URL</span>
                  </div>
                  <input 
                    type="text"
                    value={url}
                    onChange={(e) => {
                      setUrl(e.target.value);
                      if (e.target.value) {
                        setTranscript('');
                        setDocumentName('');
                      }
                    }}
                    className="w-full bg-zinc-950/40 border border-zinc-900 rounded-xl px-4 py-3 text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="https://youtube.com/watch?v=..."
                  />
                  <p className="text-[10px] text-zinc-500 mt-2">
                    Direct integration supports YouTube video transcripts, Spotify logs, or Medium articles.
                  </p>
                </div>
              </div>

              {/* Upload Document Bento Card */}
              <div 
                onClick={triggerFileSelect}
                className="glass-card rounded-[2rem] p-6 shadow-xl border-dashed border-2 border-zinc-800 hover:border-indigo-500 transition-all cursor-pointer group flex flex-col justify-center items-center text-center relative overflow-hidden"
              >
                <input 
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".txt,.doc,.docx,.pdf"
                  className="hidden" 
                />
                <div className="w-12 h-12 rounded-full bg-indigo-500/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <UploadCloud className="w-6 h-6 text-indigo-400" />
                </div>
                <h4 className="text-sm font-bold text-zinc-200">Upload Raw Document</h4>
                <p className="text-[10px] text-zinc-500 mt-1">PDF, DOCX, TXT (Maximum 20MB)</p>
              </div>

              {/* Big CTA Button block */}
              <div className="md:col-span-2 flex justify-end items-center gap-4 pt-2">
                {(transcript || url || documentName) && (
                  <button 
                    onClick={() => {
                      setTranscript('');
                      setUrl('');
                      setDocumentName('');
                    }}
                    className="text-xs text-zinc-500 hover:text-zinc-300 font-semibold uppercase tracking-wider"
                  >
                    Clear All
                  </button>
                )}
                
                <button 
                  onClick={handleExtractInsights}
                  disabled={isLoading}
                  className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-sm hover:bg-indigo-500 shadow-xl shadow-indigo-600/20 active:scale-95 transition-all duration-200 flex items-center gap-2.5 disabled:opacity-50 disabled:pointer-events-none"
                >
                  {isLoading ? (
                    <>
                      Extracting System Insights...
                      <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    </>
                  ) : (
                    <>
                      Extract Core Insights
                      <Zap className="w-4.5 h-4.5 text-white" />
                    </>
                  )}
                </button>
              </div>

            </div>

          </div>
        )}

        {/* TAB 2: PROJECTS DECK */}
        {activeTab === 'projects' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in duration-300">
            
            {/* Left sidebar: Projects listing */}
            <div className="lg:col-span-4 flex flex-col gap-4">
              <div className="flex justify-between items-center px-1">
                <span className="text-xs font-bold uppercase tracking-widest text-zinc-400">Repurposed Assets ({projects.length})</span>
                <button 
                  onClick={() => setActiveTab('source')}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                >
                  <PlusCircle className="w-3.5 h-3.5" /> Ingest New
                </button>
              </div>

              <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
                {projects.map((proj) => {
                  const isSelected = proj.id === selectedProjectId;
                  return (
                    <div 
                      key={proj.id}
                      onClick={() => {
                        setSelectedProjectId(proj.id);
                        showToast(`Switched to "${proj.title}"`, 'success');
                      }}
                      className={`p-5 rounded-2xl cursor-pointer border transition-all duration-200 relative overflow-hidden ${isSelected ? 'bg-zinc-900 border-indigo-500/50 shadow-lg shadow-indigo-500/5' : 'bg-zinc-900/40 border-zinc-800/60 hover:bg-zinc-900/60 hover:border-zinc-700'}`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase ${
                          proj.sourceType === 'url' ? 'bg-amber-500/10 text-amber-400' :
                          proj.sourceType === 'document' ? 'bg-sky-500/10 text-sky-400' :
                          'bg-indigo-500/10 text-indigo-400'
                        }`}>
                          {proj.sourceType}
                        </span>
                        <span className="text-[10px] text-zinc-500 font-mono">{proj.timestamp.split(' ')[1]}</span>
                      </div>
                      <h3 className="text-sm font-bold text-white tracking-tight line-clamp-1">{proj.title}</h3>
                      <p className="text-xs text-zinc-400 line-clamp-2 mt-1 leading-normal font-sans">{proj.summary}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right details panel: Core insights, hooks and platform social formats */}
            <div className="lg:col-span-8 flex flex-col gap-6">
              
              {/* Header Title Bar */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] font-mono text-zinc-500 tracking-wider uppercase block">CURRENT WORKING PROJECT</span>
                  <h2 className="text-2xl font-black font-['Montserrat'] text-white mt-1">{selectedProject.title}</h2>
                  <p className="text-xs text-indigo-400 font-mono mt-1 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5" /> Source: {selectedProject.sourceLabel}
                  </p>
                </div>
                
                {/* Delete project button */}
                <button 
                  onClick={() => {
                    if (projects.length <= 1) {
                      showToast('Cannot delete the last remaining project asset.', 'warning');
                      return;
                    }
                    const updated = projects.filter(p => p.id !== selectedProject.id);
                    setProjects(updated);
                    setSelectedProjectId(updated[0].id);
                    showToast('Project deleted successfully.', 'success');
                  }}
                  className="px-4 py-2 bg-zinc-950/50 hover:bg-rose-950/30 border border-zinc-800 hover:border-rose-900/50 text-zinc-400 hover:text-rose-400 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete Asset
                </button>
              </div>

              {/* Bento Grid Layer 1: Summary & Insights */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                
                {/* Thesis Summary Card */}
                <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 blur-3xl rounded-full"></div>
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">Core Synopsis</span>
                      <span className="text-[10px] text-zinc-500 font-mono">Gemini-Engineered</span>
                    </div>
                    <p className="text-sm text-zinc-300 font-['Inter'] leading-relaxed">
                      {selectedProject.summary}
                    </p>
                  </div>
                  <div className="pt-6 border-t border-zinc-900 mt-6 flex justify-between items-center text-xs">
                    <span className="text-zinc-500 font-mono">Readability Score: 92/100</span>
                    <button 
                      onClick={() => openInEditor(`${selectedProject.title} Synopsis`, selectedProject.summary)}
                      className="text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                    >
                      <Edit3 className="w-3 h-3" /> Edit Abstract
                    </button>
                  </div>
                </div>

                {/* Key Insights bullet points */}
                <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 block mb-3">Modular Insights</span>
                    <div className="space-y-4">
                      {selectedProject.insights.map((insight, idx) => (
                        <div key={idx} className="flex gap-3 items-start">
                          <span className="w-5 h-5 rounded-full bg-indigo-500/10 text-indigo-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <p className="text-xs text-zinc-300 leading-relaxed font-sans">{insight}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <button 
                    onClick={() => copyToClipboard(selectedProject.insights.join('\n\n'), 'Insights')}
                    className="w-full mt-6 py-2.5 bg-zinc-950/60 border border-zinc-800 hover:border-zinc-700 hover:text-white text-zinc-400 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy Selected Insights
                  </button>
                </div>

              </div>

              {/* Bento Grid Layer 2: Hook Generator */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Hook Generation Engine</h3>
                    <p className="text-[11px] text-zinc-500 font-['Inter'] mt-1">Scroll-stopping entry hooks synthesized using target pattern matching.</p>
                  </div>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-mono font-bold">
                    ACTIVE HOOK FORMULAS
                  </span>
                </div>

                <div className="space-y-3">
                  {selectedProject.hooks.map((hook, idx) => (
                    <div 
                      key={idx}
                      className="p-4 bg-zinc-950/30 hover:bg-zinc-950/60 border border-zinc-900 rounded-2xl flex items-center justify-between gap-4 transition-all group"
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-xs font-bold text-indigo-400 font-mono mt-0.5">#{idx + 1}</span>
                        <p className="text-xs text-zinc-200 font-sans italic leading-relaxed">"{hook}"</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button 
                          onClick={() => copyToClipboard(hook, `Hook #${idx + 1}`)}
                          className="p-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 hover:text-white text-zinc-400 rounded-lg transition-colors"
                          title="Copy Hook"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => openInEditor(`Hook Formula Option #${idx + 1}`, hook)}
                          className="px-2.5 py-1.5 bg-indigo-600/10 hover:bg-indigo-600 border border-indigo-500/20 hover:border-indigo-500 text-indigo-400 hover:text-white rounded-lg text-[10px] font-bold transition-all flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" /> Edit
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bento Grid Layer 3: Main Social Outputs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                
                {/* LinkedIn post */}
                <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded bg-[#0a66c2]/10 text-[#0a66c2] flex items-center justify-center">
                          <Linkedin className="w-3.5 h-3.5" />
                        </div>
                        <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">LinkedIn Authority Adaptation</span>
                      </div>
                      <span className="text-[10px] text-zinc-500 font-mono">Structured Layout</span>
                    </div>
                    <div className="bg-zinc-950/40 border border-zinc-900 rounded-xl p-4 h-64 overflow-y-auto">
                      <p className="text-xs text-zinc-300 whitespace-pre-wrap leading-relaxed font-sans">
                        {selectedProject.linkedinPost}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4 pt-4 border-t border-zinc-900">
                    <button 
                      onClick={() => copyToClipboard(selectedProject.linkedinPost, 'LinkedIn Post')}
                      className="flex-1 py-2.5 bg-zinc-950/60 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Copy className="w-3.5 h-3.5" /> Copy Post
                    </button>
                    <button 
                      onClick={() => openInEditor(`${selectedProject.title} LinkedIn`, selectedProject.linkedinPost)}
                      className="py-2.5 px-4 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-500 flex items-center justify-center gap-1 transition-all"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Open in Editor
                    </button>
                  </div>
                </div>

                {/* Twitter Thread */}
                <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded bg-zinc-800 text-white flex items-center justify-center">
                          <Twitter className="w-3.5 h-3.5" />
                        </div>
                        <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">Twitter/X Thread Engine</span>
                      </div>
                      <span className="text-[10px] text-zinc-500 font-mono">3-Part Flow</span>
                    </div>
                    <div className="space-y-3 h-64 overflow-y-auto pr-1">
                      {selectedProject.twitterThread.map((tweet, idx) => (
                        <div key={idx} className="p-3 bg-zinc-950/30 border border-zinc-900 rounded-xl">
                          <p className="text-xs text-zinc-300 font-sans leading-relaxed">{tweet}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4 pt-4 border-t border-zinc-900">
                    <button 
                      onClick={() => copyToClipboard(selectedProject.twitterThread.join('\n\n---\n\n'), 'Twitter Thread')}
                      className="flex-1 py-2.5 bg-zinc-950/60 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Copy className="w-3.5 h-3.5" /> Copy Thread
                    </button>
                    <button 
                      onClick={() => openInEditor(`${selectedProject.title} Twitter Thread`, selectedProject.twitterThread.join('\n\n---\n\n'))}
                      className="py-2.5 px-4 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-500 flex items-center justify-center gap-1 transition-all"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Open in Editor
                    </button>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* TAB 3: EDITOR LABORATORY */}
        {activeTab === 'editor' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in duration-300">
            
            {/* Left panel: Large editor box */}
            <div className="lg:col-span-8 glass-card rounded-[2.5rem] p-6 shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 border-b border-zinc-900 pb-3">
                  <div>
                    <span className="text-[9px] font-mono tracking-widest text-indigo-400 uppercase font-bold">Active Content Canvas</span>
                    <h2 className="text-xl font-bold text-white font-['Montserrat'] mt-0.5">{editorTitle || 'Draft Scratchpad'}</h2>
                  </div>
                  <span className="text-[10px] text-zinc-500 font-mono italic">Editable Buffer</span>
                </div>

                <textarea 
                  value={editorContent}
                  onChange={(e) => setEditorContent(e.target.value)}
                  className="w-full h-[55vh] bg-zinc-950/50 border border-zinc-900 rounded-2xl p-5 text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-indigo-500 transition-colors resize-none font-mono text-sm leading-relaxed"
                  placeholder="Select content from the Projects tab or start drafting your social content from scratch here..."
                />
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-zinc-900 mt-4">
                <span className="text-xs text-zinc-500 font-mono">
                  Characters: {editorContent.length} | Words: {editorContent.trim() ? editorContent.trim().split(/\s+/).length : 0}
                </span>
                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      setEditorContent('');
                      showToast('Editor canvas cleared.', 'warning');
                    }}
                    className="px-4 py-2 bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200 text-xs font-bold rounded-xl transition-all"
                  >
                    Clear Slate
                  </button>
                  <button 
                    onClick={() => copyToClipboard(editorContent, 'Editor draft')}
                    className="px-5 py-2.5 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-500 transition-all flex items-center gap-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy Draft
                  </button>
                </div>
              </div>
            </div>

            {/* Right panel: AI laboratory toolkit */}
            <div className="lg:col-span-4 flex flex-col gap-6">
              
              {/* Preset Assistant buttons */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl relative overflow-hidden">
                <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/5 blur-3xl rounded-full"></div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400 mb-4 block">AI Copywriter Presets</h3>
                
                <div className="space-y-2">
                  <button 
                    onClick={() => handleAIAssist('Make this text significantly punchier, scroll-stopping, and add energetic hooks.')}
                    disabled={isEditorLoading}
                    className="w-full text-left px-4 py-3 bg-zinc-950/50 hover:bg-indigo-650/10 border border-zinc-900 hover:border-indigo-500/40 text-zinc-300 hover:text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-between"
                  >
                    <span>💥 Scroll-Stopping Hook Formula</span>
                    <ChevronRight className="w-3 h-3 text-zinc-600" />
                  </button>
                  <button 
                    onClick={() => handleAIAssist('Expand this core abstract into a full, engaging, educational 3-part social media thread.')}
                    disabled={isEditorLoading}
                    className="w-full text-left px-4 py-3 bg-zinc-950/50 hover:bg-indigo-650/10 border border-zinc-900 hover:border-indigo-500/40 text-zinc-300 hover:text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-between"
                  >
                    <span>🧵 Expand to X Thread</span>
                    <ChevronRight className="w-3 h-3 text-zinc-600" />
                  </button>
                  <button 
                    onClick={() => handleAIAssist('Rewrite this in a highly authoritative, professional executive tone, suitable for Fortune 500 LinkedIn.')}
                    disabled={isEditorLoading}
                    className="w-full text-left px-4 py-3 bg-zinc-950/50 hover:bg-indigo-650/10 border border-zinc-900 hover:border-indigo-500/40 text-zinc-300 hover:text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-between"
                  >
                    <span>👔 Executive & Authoritative Tone</span>
                    <ChevronRight className="w-3 h-3 text-zinc-600" />
                  </button>
                  <button 
                    onClick={() => handleAIAssist('Inject engaging emojis, formatting bullet points, and dynamic line-breaks to make the text highly readable.')}
                    disabled={isEditorLoading}
                    className="w-full text-left px-4 py-3 bg-zinc-950/50 hover:bg-indigo-650/10 border border-zinc-900 hover:border-indigo-500/40 text-zinc-300 hover:text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-between"
                  >
                    <span>⚡ Add Spacing & Emojis</span>
                    <ChevronRight className="w-3 h-3 text-zinc-600" />
                  </button>
                  <button 
                    onClick={() => handleAIAssist('Analyze this post and append a powerful call-to-action to subscribe to an email newsletter at the end.')}
                    disabled={isEditorLoading}
                    className="w-full text-left px-4 py-3 bg-zinc-950/50 hover:bg-indigo-650/10 border border-zinc-900 hover:border-indigo-500/40 text-zinc-300 hover:text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-between"
                  >
                    <span>🎯 Inject High-Conversion CTA</span>
                    <ChevronRight className="w-3 h-3 text-zinc-600" />
                  </button>
                </div>
              </div>

              {/* Custom instructions Prompt Box */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400 mb-3 block">Custom Instruct Lab</h3>
                  <textarea 
                    value={aiInstruction}
                    onChange={(e) => setAiInstruction(e.target.value)}
                    className="w-full h-24 bg-zinc-950/40 border border-zinc-900 rounded-xl p-3 text-xs text-zinc-300 placeholder-zinc-600 focus:outline-none focus:border-indigo-500 transition-colors resize-none"
                    placeholder="e.g. Rewrite in aggressive GaryVee style, make it a quick Q&A format, or translate to professional Spanish..."
                  />
                </div>
                <button 
                  onClick={() => handleAIAssist()}
                  disabled={isEditorLoading || !aiInstruction.trim()}
                  className="w-full mt-4 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs transition-all disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/10"
                >
                  {isEditorLoading ? (
                    <>
                      Polishing Content...
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
                    </>
                  ) : (
                    <>
                      Polish with Gemini AI
                      <Zap className="w-3.5 h-3.5 text-white" />
                    </>
                  )}
                </button>
              </div>

              {/* Helpful instructions note */}
              <div className="p-4 rounded-2xl bg-zinc-900/40 border border-zinc-900 text-xs text-zinc-400">
                <p className="leading-relaxed font-sans">
                  💡 <strong>Pro Tip:</strong> Select and copy insights directly from your <strong>Projects Deck</strong> tab first, paste them here, and apply presets to instantly craft unique brand posts.
                </p>
              </div>

            </div>

          </div>
        )}

        {/* TAB 4: SYSTEM STATS & FORMULAS */}
        {activeTab === 'library' && (
          <div className="space-y-6 animate-fade-in duration-300">
            
            {/* Analytics Bento Row */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
              
              {/* Latency stat */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl flex items-center justify-center shrink-0 mb-4">
                  <Zap className="w-6 h-6 text-indigo-400" />
                </div>
                <div>
                  <div className="text-4xl font-extrabold tracking-tighter text-white">4.2ms</div>
                  <div className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest mt-2">Avg Latency Response</div>
                </div>
              </div>

              {/* Uptime Optimal Health */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider">Health Agent</span>
                </div>
                <div>
                  <div className="text-4xl font-extrabold tracking-tighter text-white">99.99%</div>
                  <div className="text-[10px] text-emerald-400 font-extrabold tracking-wider uppercase mt-1">UPTIME OPTIMAL</div>
                </div>
              </div>

              {/* Traffic processed */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl flex flex-col justify-between">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Active Traffic</h3>
                  <div className="flex gap-1">
                    <div className="w-1 h-3 bg-indigo-500 rounded-full"></div>
                    <div className="w-1 h-5 bg-indigo-500 rounded-full animate-pulse"></div>
                    <div className="w-1 h-4 bg-indigo-500 rounded-full"></div>
                  </div>
                </div>
                <div>
                  <div className="text-4xl font-extrabold text-white">8.4k</div>
                  <p className="text-[10px] text-zinc-500 mt-1 uppercase tracking-wider font-bold">Requests Per Second</p>
                </div>
              </div>

              {/* CPU Load bar charts */}
              <div className="glass-card rounded-[2rem] p-6 shadow-xl flex items-center justify-between">
                <div>
                  <div className="text-[9px] font-bold uppercase text-zinc-500 mb-2 tracking-wider">System Load</div>
                  <div className="text-3xl font-black flex items-baseline gap-1 text-white">
                    24<span className="text-lg font-normal text-zinc-600">%</span>
                  </div>
                  <p className="text-[9px] text-zinc-500 mt-1">CPU LOAD STABLE</p>
                </div>
                <div className="flex items-end gap-1.5 h-14 bg-zinc-950/50 p-2.5 rounded-2xl">
                  <div className="w-2 h-4 bg-zinc-850 rounded-full"></div>
                  <div className="w-2 h-8 bg-zinc-850 rounded-full"></div>
                  <div className="w-2 h-12 bg-indigo-500 rounded-full"></div>
                  <div className="w-2 h-6 bg-zinc-850 rounded-full"></div>
                  <div className="w-2 h-10 bg-indigo-500 rounded-full animate-pulse"></div>
                  <div className="w-2 h-5 bg-zinc-850 rounded-full"></div>
                </div>
              </div>

            </div>

            {/* Second row: Live Terminal Logs and Content Formula cards */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Live console terminal */}
              <div className="lg:col-span-5 glass-card rounded-[2.5rem] p-6 shadow-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4 border-b border-zinc-900 pb-3">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400">Live Engine Logs</h3>
                    <span className="text-[10px] px-2 py-0.5 bg-zinc-950/80 text-indigo-400 font-bold rounded font-mono animate-pulse">
                      LIVE BROADCAST
                    </span>
                  </div>
                  <div className="space-y-4 font-mono text-[11px] leading-relaxed max-h-72 overflow-y-auto">
                    {logs.map((log, idx) => (
                      <div 
                        key={idx} 
                        className={`border-l-2 pl-4 py-0.5 ${
                          log.type === 'success' ? 'border-emerald-500' :
                          log.type === 'live' ? 'border-indigo-500' :
                          log.type === 'warn' ? 'border-amber-500' :
                          'border-zinc-700 opacity-60'
                        }`}
                      >
                        <span className="text-zinc-600">[{log.time}]</span>{' '}
                        <span className="font-semibold text-zinc-300">{log.msg}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <button 
                  onClick={() => {
                    const ts = new Date().toTimeString().split(' ')[0];
                    setLogs(prev => [
                      { time: ts, msg: 'SYS_RELOAD • Logs cleared & system status re-verified', type: 'info' },
                      ...prev
                    ]);
                    showToast('Refreshed console telemetry log.', 'success');
                  }}
                  className="w-full mt-6 py-2.5 bg-zinc-950 border border-zinc-900 text-zinc-400 hover:text-white hover:border-zinc-800 text-xs font-bold rounded-xl transition-all"
                >
                  Refresh Console Telemetry
                </button>
              </div>

              {/* Viral Content Formula Library */}
              <div className="lg:col-span-7 glass-card rounded-[2.5rem] p-6 shadow-xl">
                <div className="flex justify-between items-center mb-4 border-b border-zinc-900 pb-3">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400">Social Content Formulas</h3>
                    <p className="text-[11px] text-zinc-500 font-sans mt-0.5">High-performance structures leveraged by top 1% content creators.</p>
                  </div>
                  <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded-full font-mono font-bold uppercase">
                    MODULAR ENGINE
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[300px] overflow-y-auto pr-1">
                  
                  {/* Formula 1 */}
                  <div className="p-4 bg-zinc-950/30 border border-zinc-900 hover:border-indigo-500/30 rounded-2xl transition-all">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 bg-indigo-500 rounded-full"></span> The Question Disruptor
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-2 font-sans leading-relaxed">
                      "Why does [Standard Assumption] keep you stuck? (Hint: It is a trap 🧵)"
                    </p>
                    <p className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider font-bold mt-3">Used for Twitter/X threads</p>
                  </div>

                  {/* Formula 2 */}
                  <div className="p-4 bg-zinc-950/30 border border-zinc-900 hover:border-indigo-500/30 rounded-2xl transition-all">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 bg-indigo-500 rounded-full"></span> The Contrarian Blueprint
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-2 font-sans leading-relaxed">
                      "[Industry Action] is dead. If you're still doing it, you are losing 90% of conversions."
                    </p>
                    <p className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider font-bold mt-3">Used for High CTR Hooks</p>
                  </div>

                  {/* Formula 3 */}
                  <div className="p-4 bg-zinc-950/30 border border-zinc-900 hover:border-indigo-500/30 rounded-2xl transition-all">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 bg-indigo-500 rounded-full"></span> The Modular Case Study
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-2 font-sans leading-relaxed">
                      "We spent 100+ hours analyzing [Asset]. Here are the exactly 3 design frameworks that scale."
                    </p>
                    <p className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider font-bold mt-3">Used for LinkedIn Authority posts</p>
                  </div>

                  {/* Formula 4 */}
                  <div className="p-4 bg-zinc-950/30 border border-zinc-900 hover:border-indigo-500/30 rounded-2xl transition-all">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 bg-indigo-500 rounded-full"></span> The First Principles Rewrite
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-2 font-sans leading-relaxed">
                      "Stop copying your competitors. Strip the challenge down to basic raw assets."
                    </p>
                    <p className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider font-bold mt-3">Used for Long-form insights</p>
                  </div>

                </div>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* Footer Bottom responsive Navigation bar */}
      <nav className="fixed bottom-0 left-0 w-full z-50 bg-[#09090b]/90 border-t border-zinc-900 py-3 px-4 shadow-[0_-8px_30px_rgba(0,0,0,0.5)] md:hidden flex justify-around items-center rounded-t-2xl backdrop-blur-md">
        <button 
          id="nav-source-mobile"
          onClick={() => setActiveTab('source')}
          className={`flex flex-col items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${activeTab === 'source' ? 'text-indigo-400 bg-zinc-900/60' : 'text-zinc-500'}`}
        >
          <PlusCircle className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-wider">Source</span>
        </button>
        <button 
          id="nav-projects-mobile"
          onClick={() => setActiveTab('projects')}
          className={`flex flex-col items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${activeTab === 'projects' ? 'text-indigo-400 bg-zinc-900/60' : 'text-zinc-500'}`}
        >
          <LayoutGrid className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-wider">Projects</span>
        </button>
        <button 
          id="nav-editor-mobile"
          onClick={() => setActiveTab('editor')}
          className={`flex flex-col items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${activeTab === 'editor' ? 'text-indigo-400 bg-zinc-900/60' : 'text-zinc-500'}`}
        >
          <Edit3 className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-wider">Editor</span>
        </button>
        <button 
          id="nav-library-mobile"
          onClick={() => setActiveTab('library')}
          className={`flex flex-col items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${activeTab === 'library' ? 'text-indigo-400 bg-zinc-900/60' : 'text-zinc-500'}`}
        >
          <BookOpen className="w-5 h-5" />
          <span className="text-[9px] font-bold uppercase tracking-wider">Library</span>
        </button>
      </nav>

    </div>
  );
}
